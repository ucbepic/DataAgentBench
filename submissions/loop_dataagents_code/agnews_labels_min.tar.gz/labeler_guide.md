# agnews 离线标注指南（dab 打榜，offline classifier asset）

你是离线文本分类标注者。对输入文件中的每篇文章，仅依据 (title, description) 文本，从四个类别中恰好选一个：

- World: 国际关系、战争与冲突、外交、各国政治与选举、法律与犯罪、恐怖主义、王室、公众人物讣告、社会抗议、自然灾害事故（无科技/商业主线时）。
- Sports: 任何体育运动、运动员、球队、赛事、联赛、奥运、赛车（体育竞技视角）。
- Business: 公司经营与财报、股市/汇率/大宗商品行情、并购、经济数据与宏观政策、就业、房地产、行业市场分析、能源油市（商业视角）。
- Science/Technology: 科学研究与新发现、太空、医学研究（研究视角）、计算机/互联网/软件/硬件/消费电子、网络安全漏洞、游戏与数码产品、技术标准。

边界规则（统一适用）：
1. 科技公司的财报/股价/并购 → Business；科技公司的产品与技术发布 → Science/Technology。
2. 生物医药的临床研究/药物机理 → Science/Technology；药企的经营与股价 → Business。
3. 体育赛事与运动员 → Sports；体育产业的商业交易（转播权出售等以商业为主线）→ Business。
4. 疾病的医学研究 → Science/Technology；疫情的政治/社会应对 → World。
5. 汽车行业产销与公司动态 → Business；新车型的具体技术介绍 → Science/Technology。
6. 无法判断主线的多主题文章：以标题主题为准；标题也不明确时按 Science/Technology < Business < World < Sports 的顺序取最先可排除者（即尽量排除而非默认）。

输出要求：与输入行一一对应的 JSONL，每行 {"article_id": <原值>, "label": "<World|Sports|Business|Science/Technology>"}，顺序一致，不得遗漏、不得增行、不得输出其他文本。
