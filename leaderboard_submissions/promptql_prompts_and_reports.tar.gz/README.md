# PromptQL submission: prompts and reports

This archive goes with the PromptQL leaderboard submission (Claude Fable 5.2 and GPT-6.2 Astra).

- `prompts/wrapper-template.txt`: the prompt wrapper, once
- `prompts/full/<dataset>__q<N>.txt`: the full input sent for 51 questions
- `prompts/question-only/GITHUB_REPOS__q<N>.txt`: the question text for GITHUB_REPOS queries 1, 3 and 4
- `reports/coverage-by-dataset-model.csv`: per dataset and model, how many trials have a full step list, code and program output in their trace
- `reports/resends-per-slot.csv`: the 62 trials that were sent a second time
- `reports/prompt-coverage.csv`: which prompt file covers which question

GITHUB_REPOS query 2 was run later than the rest. Its full input is `prompts/full/GITHUB_REPOS__q2.txt`. The three reports were made before that and don't cover it.

The answers and traces are in the other files of the submission. The same inputs were used for both models.
