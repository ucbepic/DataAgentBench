# DG (GLM-5.3) execution traces — 270 trials

Layout: `dg_glm53_traces/<dataset>/query<N>/trial<R>/final_agent.json`

Each `final_agent.json` embeds the complete agent message history
(`agent_state.messages`: every user/ai/tool message, tool calls and their
full outputs, plans, todos) — this is the execution trace for that trial —
together with: dataset, query_id, run (0–4), deployment (model id),
final_result (recorded answer), terminate_reason, is_valid (pass indicator),
elapsed, and token usage.

Note: `agent_state.messages` is the agent-visible history. The scorer-only
fields `ground_truth` and `is_valid` are attached after termination by the
evaluation runner; they are not part of the agent's context during the run.
